
	<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
		<div class="menu_section">
			<h3>Navegación</h3>

			<ul class="nav side-menu">
				<li><a href="<?php echo site_url('admin/index'); ?>"><i class="fa fa-home"></i> <?php echo _( 'Dashboard' ); ?></a></li>

				<!-- <li><a><i class="fa fa-database"></i> <?php echo _( 'Orders' ); ?> <span class="fa fa-chevron-down"></span></a> -->
				<li><a href="<?php echo site_url('admin/pedidos'); ?>"><i class="fa fa-database"></i> <?php echo _( 'Pedidos en Mesa' ); ?> </a></li>
				<li><a href="index.php?page=apartaments"><i class="fa fa-database"></i> <?php echo _( 'Delivery' ); ?> </a></li>
				<li><a href="index.php?page=users"><i class="fa fa-database"></i> <?php echo _( 'Reservas' ); ?> </a></li>
				<li><a href="index.php?page=users"><i class="fa fa-database"></i> <?php echo _( 'Usuarios' ); ?> </a></li>

			</ul>

    </div>
  </div>
