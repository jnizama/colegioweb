<div class="page-pedidos container">
  <div class="page-title">
    <div class="title_left">
      <h3>Pedidos <small>efectuados en su local</small></h3>
    </div>
  </div>


  <div class="clearfix"></div>

  <div class="row derecha">
    <div class="col-md-1 col-sm-2 col-xs-2 col-lg-1">
      <div id="block_company_dashboard">
        <label for="message-text" class="control-label">Sucursal:</label>
      </div>
    </div>
    <div class="col-md-3 col-sm-3 col-xs-4 col-lg-3">
      <div id="block_company_dashboard" style="display:visibility" >
        <select class="form-control" id="dropdownCompanyUser" class="selectpicker" ></select>
      </div>
    </div>

    <div class="col-md-1 col-sm-1 col-xs-2 col-lg-1">
      <div id="block_company_dashboard">
        <label for="message-text" class="control-label">Estado:</label>
      </div>
    </div>
    <div class="col-md-3 col-sm-3 col-xs-4 col-lg-3 izquierda">
      <!-- Standard button -->
      <!-- <button type="button" class="btn btn-warning estadopedido">PENDIENTE</button> -->
      <select class="form-control" id="dropdownCompanyUser" class="selectpicker" ></select>
    </div>
  </div>

  <div class="row derecha">
    <div class="col-md-2 col-sm-2 col-xs-3 col-lg-1">
      <div id="block_company_dashboard">
        <label for="message-text" class="control-label">Fecha Inicio:</label>
      </div>
    </div>
    <div class="col-md-6 col-sm-3 col-xs-9 col-lg-3">
      <div id="block_company_dashboard" style="display:visibility" >
        <div class="input-daterange input-group" id="datepicker">
          <input type="text" class="input-sm form-control" name="start" />
          <span class="input-group-addon">to</span>
          <input type="text" class="input-sm form-control" name="end" />
      </div>
      </div>
    </div>
  </div>

<div class="container">

  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_content">
          <table id="dtCompanies" class="table table-striped table-bordered table">
            <thead>
              <tr>
                <th>N•</th>
                <th>Cant.Platos</th>
                <th>D&iacute;a</th>
                <th>Hora</th>
                <th>Estado</th>
                <th>Comprobante</th>
                <th>Igv</th>
                <th>SubTotal</th>
                <th>Total</th>
              </tr>
            </thead>


            <tbody>

            </tbody>

            <tfoot>
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td style='text-align:center'>
                      Totales
                  </td>
                  <td style='text-align:center'>
                      <label id="lbl_tot_Pedidos" value="">
                  </td>
                </tr>
            </tfoot>

          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-2 col-sm-2 col-xs-2 col-lg-1">
        <button type="button" id="btnEditar" data-toggle="modal" data-target="#modalDetaPedido" class="btn btn-primary">Editar</button>
    </div>
    <div class="col-md-2 col-sm-2 col-xs-3 col-lg-1">
        <button type="button" class="btn btn-primary">Consultar</button>
    </div>
    <div class="col-md-2 col-sm-2 col-xs-4 col-lg-2">
        <button type="button" class="btn btn-success">Imprimir Ticket</button>
    </div>
    <div class="col-md-2 col-sm-2 col-xs-2 col-lg-1">
        <button type="button" class="btn btn-danger">Eliminar</button>
    </div>
 </div>
</div>

</div>

<!-- Modal to New Company -->
<div id="modalDetaPedido" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Edici&oacute;n del Pedido</h4>
      </div>
      <div class="modal-body">
        <form>
        <div class="row" >

         <div class="col-sm-2 col-md-2 col-xs-2 derecha">
           <label for="message-text" class="control-label">Autocorrelativo:</label>
         </div>
         <div class="col-sm-3 col-md-3 col-xs-3">
           <label for="message-text" class="control-label derecha">0002</label>
         </div>

         <div class="col-sm-3 col-md-3 col-xs-2 derecha">
           <label for="message-text" class="control-label">M&oacute;dulo:</label>
         </div>
         <div class="col-sm-4 col-md-4 col-xs-4">
           <label for="message-text" class="control-label izquierda">Pedidos</label>
         </div>

       </div>

       <div class="row" >
         <div class="col-sm-2 col-md-2 col-xs-2 derecha">
           <label for="message-text" class="control-label">Cant.Platos:</label>
         </div>
         <div class="col-sm-3 col-md-3 col-xs-3">
           <label for="message-text" class="control-label izquierda">13</label>
         </div>

         <div class="col-sm-3 col-md-3 col-xs-2 derecha">
           <label for="message-text" class="control-label">Fecha/Hora Pedido:</label>
         </div>
         <div class="col-sm-3 col-md-3 col-xs-3">
           <label for="message-text" class="control-label">01/01/2007 09:33am</label>
         </div>

       </div>
       <div class="row" >
         <div class="col-sm-2 col-md-2 col-xs-2 derecha">
           <label for="message-text" class="control-label">Fecha/Hora:</label>
         </div>
         <div class="col-sm-4 col-md-4 col-xs-4">
           <label for="message-text" class="control-label izquierda">11/01/2007 12:23pm</label>
         </div>
         <div class="col-sm-2 col-md-2 col-xs-2 derecha">
           <label for="message-text" class="control-label">Comprobante:</label>
         </div>
         <div class="col-sm-4 col-md-4 col-xs-4">
           <label for="message-text" class="control-label izquierda">Boleta</label>
         </div>
       </div>

       <div class="row" >
         <div class="col-sm-2 col-md-2 col-xs-2 derecha">
           <label for="message-text" class="control-label">Cliente:</label>
         </div>
         <div class="col-sm-4 col-md-4 col-xs-4">
           <label for="message-text" class="control-label izquierda">XXXXXXXXXXXXXXXXXXXXXXXXX</label>
         </div>
         <div class="col-sm-2 col-md-2 col-xs-2 derecha">
           <label for="message-text" class="control-label">Comprobante:</label>
         </div>
         <div class="col-sm-4 col-md-4 col-xs-4">
           <label for="message-text" class="control-label izquierda">Boleta</label>
         </div>
       </div>

       <div class="row" >
         <div class="col-sm-2 col-md-2 col-xs-2 derecha">
           <label for="message-text" class="control-label">Mesa Confir.:</label>
         </div>
         <div class="col-sm-4 col-md-4 col-xs-4">
           <input type="checkbox" value="1" checked="1">
         </div>
         <div class="col-sm-2 col-md-2 col-xs-2 derecha">
           <label for="message-text" class="control-label">N Mesa:</label>
         </div>
         <div class="col-sm-4 col-md-4 col-xs-4">
           <label for="message-text" class="control-label izquierda">12</label>
         </div>
       </div>

       <div class="row">
         <div class="col-md-12 col-sm-12 col-xs-12">
           <div class="x_panel">
             <div class="x_content">
               <table id="dtDetallePedido" class="table table-striped table-bordered table">
                 <thead>
                   <tr>
                     <th>N•</th>
                     <th>Plato</th>
                     <th>Cant.</th>
                     <th>Precio</th>
                     <th>SubTotal</th>
                     <th>Eliminar</th>
                   </tr>
                 </thead>


                 <tbody>

                 </tbody>

                 <tfoot>
                     <tr>
                       <td></td>
                       <td></td>
                       <td></td>

                       <td class="derecha">
                           Total
                       </td>
                       <td style='text-align:center'>
                           <label id="lbl_tot_Pedidos" value="">
                       </td>
                       <td></td>
                     </tr>
                 </tfoot>

               </table>
             </div>
           </div>
         </div>
       </div>


       </form>
      </div>
      <div class="modal-footer">
        <button type="button" id="btnSaveCompany" class="btn btn-default" data-dismiss="modal">Save</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
      </div>
    </div>

  </div>
</div>
