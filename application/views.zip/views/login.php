<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>BBBite.com Admin Panel</title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">
    <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.min.css">

    <link href="<?php echo base_url(); ?>css/bootstrap-select.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url(); ?>css/font-awesome.min.css" rel="stylesheet">
    <!-- Custom Theme Style -->

    <link href="<?php echo base_url(); ?>css/login.css" rel="stylesheet">
  </head>

  <body class="login">

    <div class="container">
   <form class="form-signin">
     <img class="imagecenter" src="<?php echo base_url(); ?>images/logo.png" style="width:130px; height: 130px" />
     <h3 class="form-signin-heading">Gestor de Restaurantes</h3>
     <h3 class="form-signin-heading">Inicio de sesión</h3>
       <!-- <select id="dropdownCompany" class="selectpicker" data-width="100%">

      </select> -->


     <label for="inputEmail" class="sr-only">User name</label>
     <input type="text" id="inputUser" class="form-control" placeholder="User" required autofocus>
     <label for="inputPassword" class="sr-only">Password</label>
     <input type="password" id="inputPassword" class="form-control" placeholder="Password" required>
     <div class="checkbox">
       <label>
         <input type="checkbox" value="remember-me"> Remember me
       </label>
     </div>
     <span class="inputPasswordMessageWrong">user or password invalid</span>

     <button class="btn btn-lg btn-primary btn-block" id="btnSignin" >Sign in</button>
   </form>

 </div> <!-- /container -->



  </body>

  <!-- jQuery -->
  <script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>js/bootstrap-select.js"></script>
  <script src="<?php echo base_url(); ?>js/login.js"></script>

</html>
